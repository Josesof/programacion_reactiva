package com.rastreador.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppClienteRastreadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppClienteRastreadorApplication.class, args);
	}

}
